function [x,c]=rebuildx(x0, y0, y, eps );

%function x=rebuildx(x0, y0, y, eps );

[n0,p0] = size(x0);

if nargin < 4
    eps = 1.0/n0;
end;

n = length(y);

v = var(y0);

a = repmat( y, 1, n0 ) - repmat( y0', n, 1 );


%c = ( 1/eps/sqrt(2*pi*v) ) .*  exp( (-1/2/eps^2/v) .*( a.^2) ) ;

c = exp( (-1/2/eps^2/v) .*( a.^2) ) ;

sc = sum(c,2);
sc(sc==0) = 1;

c = c ./ repmat(sc,1,n0);

%c = c + (1/n0/mean(y0)) * (y-c*y0)*ones(1,n0);

x = c * x0;

