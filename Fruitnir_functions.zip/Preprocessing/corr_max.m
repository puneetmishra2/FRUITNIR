function x_corr = corr_max(x0);
[n,p] = size(x0);
maxX = max(x0');
x_corr = x0./(maxX'*(ones(1,p)));
% For the test set, the same function is used