function X_corr= corr_movpol(X0)
winsize = 15;
degree = 2;
[n, p] = size(X0);
w = floor(winsize/2);
% Extend the spectrum by symmetry
x = [X0(:,w:-1:1), X0, X0(:,end-w+1:end)];
% Smooth
for j=1:n
for i= w+1:w+p;
pol = polyfit(i-w:i+w, x(j,i-w:i+w), degree);
X_corr(j,i-w)=polyval(pol,i);
end;
end