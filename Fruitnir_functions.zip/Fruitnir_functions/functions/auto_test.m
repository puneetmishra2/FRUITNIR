function [ax] = auto_test(x,mx,stdx)
%AUTO Autoscales matrix to mean zero unit variance

[m,n] = size(x);
ax    = (x-mx(ones(m,1),:))./stdx(ones(m,1),:);

