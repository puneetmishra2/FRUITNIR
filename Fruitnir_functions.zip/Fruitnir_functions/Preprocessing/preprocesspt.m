function [ Z ] = preprocesspt( x, ch,win,pol,der)
addpath([pwd '/Preprocessing']);
% will recived input from the handle of choice and perform the normalisaton

if (ch==1)
    Z = x;
elseif (ch==2)
    Z = savgol(x,win,pol);
elseif (ch==3)
    Z = corr_movav(x);
elseif (ch==4)
    Z = corr_movpol(x);   
elseif (ch==5)
    Z = corr_pct(x);
elseif (ch==6)
    Z = corr_ica(x);    
end

end

