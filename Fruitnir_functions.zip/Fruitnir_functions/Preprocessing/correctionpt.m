function [ Z,res ] = correctionpt( x, ch)
addpath([pwd '/Preprocessing']);
% function will recieve the handle from GUI to select and run a type of
% preporcessing on the data matrix
if (ch==1)
    Z = x;
elseif (ch==2)
    Z = detrending(x); %test set same function
elseif (ch==3)
    Z = corr_offset(x);  %test set same function
elseif (ch==4)
    Z = corr_msc(x); %test set same function
elseif (ch==5)
    Z = DeSpline(x);  %test set same function  
elseif (ch==6)
    Z = corr_als(x);   %test set same function
elseif (ch==7)
    Z = corr_snv(x);   %test set same function  
elseif (ch==8)
    [Z,res] = vsn(x);   %test set different as weights need to carried forward
    %vsn_weigths{1,nB} = res;
elseif (ch==9)           
    Z = corr_pqn(x);    %test set same function 
elseif (ch==10)
    Z = corr_rnv(x);  %test set same function  
elseif (ch==11)
    Z = corr_log(x);   %test set same function  
elseif (ch==12)
    Z = corr_snv(x');    %test set same function  
    Z = Z';
elseif (ch==13)
    Z = savgol(x,15,2,1);   %test set same function  
elseif (ch==14)
    Z = savgol(x,15,2,2);    %test set same function  
elseif (ch==15)
    Z = corr_minmax(x);      %test set same function  
elseif (ch==16)
    Z = corr_norm(x);      %test set same function  
elseif (ch==17) 
    Z = corr_range(x);       %test set same function  
elseif (ch==18)
    Z = corr_max(x);          %test set same function  
end    

end



