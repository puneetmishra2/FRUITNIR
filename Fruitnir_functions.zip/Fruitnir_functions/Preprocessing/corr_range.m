function x_corr = corr_range(x0);
[n,p] = size(x0);
minX = min(x0');
maxX = max(x0');
% Calculate the range
rngX=maxX-minX;
% Scale the spectra
x_corr=x0./(rngX'*(ones(1,p)));
% For the test set, the same function is used