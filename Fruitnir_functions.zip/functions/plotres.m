function hf=plotres(ymes, ypred, unit, titre, style, trend);

%   h=plotres(ymes, ypred, unit, titre, style, trend);
% fonction de trac� valeurs pr�dites / valeurs mesur�es
% ymes : val mesur�es
% ypred: val pr�dites
% unit : cha�ne ajout�e au label des axes, p. ex. '� Brix' (optionnel)
% titre : titre du graphique (optionnel)
% style : style d etrace passe a plot p.ex. 'r+' (optionnel)
% trend : ajout d'une droite de tendance 0/1 (optionnel)

if nargin < 6
    trend = 0;
end;

if nargin>4
    hf=plot(ymes,ypred,style);
else
    hf=plot(ymes,ypred,'ok');
end;

a1=min(min([ymes ypred]));
a2=max(max([ymes ypred]));
hold on;
plot([a1 a2],[a1 a2],'k');
hold off;

set(get(gcf,'currentaxes'),'xlim',[a1 a2])
set(get(gcf,'currentaxes'),'ylim',[a1 a2])

if nargin >= 3
  xlabel(sprintf('Actual values (%s)', unit ));
  ylabel(sprintf('Predicted values (%s)', unit ));
else
  unit=''; 
  xlabel('Measured values');
  ylabel('Predicted values' );
end;

bs = mean( ypred - ymes );
se = std( ypred - ymes );
k = corrcoef(ypred,ymes).^2; r2 = k(1,2);

if nargin < 4
    h=text( a1 + (a2-a1)/30, a2-(a2-a1)/20, sprintf('R^2 = %.3g ; Bias = %.3g %s ; SEP_C = %.3g %s', r2, bs, unit, se, unit ));
else
    h=text( a1 + (a2-a1)/30, a2-(a2-a1)/20, sprintf('%s\nR^2 = %.3g ; Bias = %.3g %s ; SEP_C = %.3g %s', titre, r2, bs, unit, se, unit ));
end;

set(h,'HorizontalAlignment', 'left');
set(h,'VerticalAlignment', 'top');

if trend ~= 0
    b = [ymes ymes.*0+1] \ ypred;
    hold on;
    plot([a1 a2],[[a1;a2] [1;1]]*b,'k:');
    hold off;
    if nargin < 4
        h=text( a1 + (a2-a1)/30, a2-(a2-a1)/5, sprintf('slope = %.3g  offset = %.3g', b(1), b(2) ) );
    else
        h=text( a1 + (a2-a1)/30, a2-(a2-a1)/5, sprintf('slope = %.3g  offset = %.3g %s', b(1), b(2), unit ) );
    end;

end;




