function x_corr = corr_norm(x0);
[n,p] = size(x0);
% Calculate the norm
nrmX = sqrt(sum(x0.^2,2));
% Scale the spectra
x_corr=x0./(nrmX*(ones(1,p)));