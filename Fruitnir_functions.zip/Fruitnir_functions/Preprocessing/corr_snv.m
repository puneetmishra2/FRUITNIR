function X_corr = corr_snv(X0);
[n, p] = size(X0);
% Row center
mXr = mean(X0')';
Xr_Cent =X0-mXr*ones(1,p);
% Row standardize
stdXr = std(Xr_Cent')';
X_corr=Xr_Cent./(stdXr*ones(1,p));