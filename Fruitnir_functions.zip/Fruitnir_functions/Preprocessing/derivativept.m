function [ Z ] = derivativept( x, ch,win_d,pol_d,der_d)
addpath([pwd '/Preprocessing']);
if (ch==1)
    Z = x;
elseif (ch==2)
    Z = savgol(x,15,2,1);
elseif (ch==3)
    Z = savgol(x,15,2,2);
elseif (ch==4)
    Z = savgol(x,win_d,pol_d,der_d);
end   

end